const express = require("express");
const mummasBlog = require("../src/mummasBlog/routesConfig")
const router = express.Router();
/* GET home page. */
router.get("/", function (req, res, next) {
  return res.send({
    apiResponseCode: "200",
    apiResponeMessage: "success",
    apiResponseData: { responseCde: "200", responseMessage: "success" },
    apiResponseFrom: "Node Api",
    apiResponseTime: new Date().toLocaleString(),
  });
});
/***************************** add new routes here ****************************************/
router.use("/foodblog",mummasBlog);


module.exports = router;
