const http = require("http");

exports.executeGetCurlWithOptions = (hostname, port, path, headers) => {
	try {
		const options = {
			hostname: hostname,
			port: port,
			path: path,
			method: "GET",
			headers: headers
		};
		return new Promise((resolve, reject) => {
			const req = http.get(options, (res) => {
				res.on("data", (d) => {
					resolve({ statusCode: res.statusCode, result: d.toString() });
				});
			});
			req.on("error", (e) => {
				return resolve({ statusCode: "400", result: e.toString() });
			});
			req.end();
		});
	} catch (error) {
		return { statusCode: "500", result: "smething went wrong" + error };
	}
};

exports.executePostCurl = (hostname, port, path, headers, method, reqData) => {
	try {
		const options = {
			hostname: hostname,
			port: port,
			path: path,
			method: method,
			headers: headers
		};
		return new Promise((resolve, reject) => {
			const req = http.request(options, (res) => {
				let body = "";
				res.on("data", (chunk) => {
					body = body + chunk;
				});
				res.on("end", () => {
					return resolve({ statusCode: res.statusCode, result: body.toString() });
				});
			});
			req.on("error", (e) => {
				resolve({ statusCode: "400", result: e.toString() });
			});
			req.write(reqData);
			req.end();
		});
	} catch (error) {
		return { statusCode: "500", result: "smething went wrong" + error };
	}
};
