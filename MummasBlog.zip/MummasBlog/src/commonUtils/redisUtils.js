const { client } = require("./redisConnection");

exports.getRedisData = (keyName) => {
  try {
    return new Promise((resolve, reject) => {
      redisClient.get(keyName, (err, reply) => {
        if (err) {
          resolve({ responseCode: "500", responseMessage: "can not connect to redis server", data: "" });
        } else if (!reply) {
          resolve({ responseCode: "400", responseMessage: "No redis data avilable for this user", data: "" });
        } else {
          reply = JSON.parse(reply);
          resolve({ responseCode: "200", responseMessage: "Success", data: reply });
        }
      });
    });
  } catch (error) {
    return { responseCode: "500", responseMessage: "something went wrong" + error, data: "" };
  }
};


exports.delRedisData = (keyName) => {
  try {
    return new Promise((resolve, reject) => {
      redisClient.del(keyName, (err, reply) => {
        if (err) {
          resolve({ responseCode: "500", responseMessage: "can not delete redis key", data: "" });
        } else if (!reply) {
          resolve({ responseCode: "400", responseMessage: "No redis data avilable for this user", data: "" });
        } else {
          reply = JSON.parse(reply);
          resolve({ responseCode: "200", responseMessage: "Success", data: reply });
        }
      });
    });
  } catch (error) {
    return { responseCode: "500", responseMessage: "something went wrong" + error, data: "" };
  }
};


exports.setRedisData = (keyName, data) => {
  try {
    return new Promise((resolve, reject) => {
      redisClient.set(keyName, JSON.stringify(data), (err, reply) => {
        if (err) {
          return resolve({ responseCode: "500", responseMessage: "can not set redis data", data: "" });
        }
        return resolve({ responseCode: "200", responseMessage: "Success" });
      });
    });
  } catch (error) {
    return { responseCode: "500", responseMessage: "something went wrong" + error, data: "" };
  }
};

exports.setExpireTimeForRedisData = (keyName, time) => {
  try {
    return new Promise((resolve, reject) => {
      redisClient.expire(keyName, parseInt(time), (err, reply) => {
        if (err) {
          return resolve({ responseCode: "500", responseMessage: "can not set redis key to expire", data: "" });
        }
        return resolve({ responseCode: "200", responseMessage: "Success" });
      });
    });
  } catch (error) {
    return { responseCode: "500", responseMessage: "something went wrong" + error, data: "" };
  }
};



