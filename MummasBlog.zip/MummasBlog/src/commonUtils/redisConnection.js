const config = require('../../environment/environmentVar');
const redis = require('redis');

class redisConnection {

    createConnection()
    {
        var redisPool = require('redis-connection-pool')('myRedisPool', {
            host: config.redisHost, 
            port: config.redisPort, 
            max_clients:config.redisMaxClient, 
            perform_checks: false,
            database:0,
            options: {
            auth_pass: config.redisAuth
            } 
        }); 
        return redisPool;
    }
    setConnection(redisPool)
    {
        this.redisPool=redisPool;
    }
    getConnection() {
        return this.redisPool;
    }
    closeConnection() {
        this.redisPool.quit();
    }
}
 

var redisClientObj = new redisConnection(); 

module.exports = redisClientObj;