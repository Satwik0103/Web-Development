const crypto = require("crypto");
const redisUtils = require("./redisUtils");

exports.convertDatetime = (dt) => {
  try {
    dt = new Date(dt);
    let dateTime = `${dt.getFullYear().toString().padStart(4, "0")}-${(
      dt.getMonth() + 1
    )
      .toString()
      .padStart(2, "0")}-${dt.getDate().toString().padStart(2, "0")} ${dt
      .getHours()
      .toString()
      .padStart(2, "0")}:${dt.getMinutes().toString().padStart(2, "0")}:${dt
      .getSeconds()
      .toString()
      .padStart(2, "0")}`;
    return dateTime;
  } catch (error) {
    return "";
  }
};

exports.createHMAC = (algo, key, data) => {
  try {
    // let text = JSON.stringify(data);
    const hash = crypto
      .createHmac(algo, key)
      .update(data, "utf8")
      .digest("hex");
    let hasDataInBase64 = Buffer.from(hash).toString("base64");
    return {
      responseCode: "200",
      responseMessage: "success",
      responseData: hasDataInBase64,
    };
  } catch (error) {
    return {
      responseCode: "500",
      responseMessage: "something went wrong" + error,
    };
  }
};

exports.getBasicAuth = (userName, password) => {
  try {
    let basicAuth = `Basic ${Buffer.from(`${userName}:${password}`).toString(
      "base64"
    )}`;
    return { responseCode: "200", basicAuth: basicAuth };
  } catch (error) {
    return {
      responseCode: "500",
      responseMessage: "something went wrong@GET_BASIC_AUTH" + error,
    };
  }
};

exports.detectBrowserInfo = (req) => {
  try {
    let nAgt = req.headers["user-agent"];
    let browserName = req.appName;
    let nameOffset, verOffset, ix;
    // In Opera, the true version is after "Opera" or after "Version"
    if ((verOffset = nAgt.indexOf("Opera")) != -1) {
      browserName = "Opera";
      fullVersion = nAgt.substring(verOffset + 6);
      if ((verOffset = nAgt.indexOf("Version")) != -1)
        fullVersion = nAgt.substring(verOffset + 8);
    }
    // In MSIE, the true version is after "MSIE" in userAgent
    else if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
      browserName = "Microsoft Internet Explorer";
      fullVersion = nAgt.substring(verOffset + 5);
    }
    // In Microsoft Edge, the true version is after "Edge"
    else if ((verOffset = nAgt.indexOf("Edg")) != -1) {
      browserName = "Microsoft Edge";
      fullVersion = nAgt.substring(verOffset + 4);
    }
    // In Chrome, the true version is after "Chrome"
    else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
      browserName = "Chrome";
      fullVersion = nAgt.substring(verOffset + 7);
    }
    // In Safari, the true version is after "Safari" or after "Version"
    else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
      browserName = "Safari";
      fullVersion = nAgt.substring(verOffset + 7);
      if ((verOffset = nAgt.indexOf("Version")) != -1)
        fullVersion = nAgt.substring(verOffset + 8);
    }
    // In Firefox, the true version is after "Firefox"
    else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
      browserName = "Firefox";
      fullVersion = nAgt.substring(verOffset + 8);
    } else if (
      (nameOffset = nAgt.lastIndexOf(" ") + 1) <
      (verOffset = nAgt.lastIndexOf("/"))
    ) {
      browserName = nAgt.substring(nameOffset, verOffset);
      fullVersion = nAgt.substring(verOffset + 1);
    }
    if ((ix = fullVersion.indexOf(";")) != -1)
      fullVersion = fullVersion.substring(0, ix);
    if ((ix = fullVersion.indexOf(" ")) != -1)
      fullVersion = fullVersion.substring(0, ix);
    majorVersion = parseInt("" + fullVersion, 10);
    let browserInfo = { browserName: browserName, version: fullVersion };
    return browserInfo;
  } catch (err) {
    return "";
  }
};

exports.sessionValidationCheck = async (
  sessionKey,
  sessionReferenceNumber,
  key
) => {
  try {
    let keyName =key;
    let redisVal = await redisUtils.getRedisData(keyName);
    for(let i=0;i<redisVal.data.length;i++){
    if (
      redisVal.data[i].sessionKey === sessionKey &&
      redisVal.data[i].sessionReferenceNumber === sessionReferenceNumber
    ) {
      return true;
    }
  }
    return false;
  } catch (err) {
    return false;
  }
};
