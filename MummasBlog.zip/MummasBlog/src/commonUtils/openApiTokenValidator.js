const responseHandler = require("../commonUtils/responseHandler");
const redisUtils = require("../commonUtils/redisUtils");
const commonUtis = require("../commonUtils/utility");

exports.validateHeaders = (req, res, next) => {
	try {
		let { authorization, authtoken } = req.headers;
		let apiResposne = "";
		let err = 0;
		let errMessage = "";
		if (!authorization) {
			err = 1;
			errMessage = "Please Provide a valid Basic authorization";
		}
		if (!authtoken) {
			err = 1;
			errMessage = "Please Provide a valid auth token";
		} else {
			err = 0;
			errMessage = "";
		}
		if (err) {
			apiResposne = { serviceType: "OPEN_API_HEADER_VALIDATION", apiResponseData: { responseCode: "400", responseMessage: errMessage } };
			return res.send(responseHandler.transform(apiResposne));
		} else {
			next();
		}
	} catch (error) {
		let apiResposne = { code: "500", message: "something went wrong" + error, serviceType: "OPEN_API_HEADER_VALIDATION", apiResponseData: {} };
		return res.send(responseHandler.transform(apiResposne));
	}
};

exports.validateAuthForOpenApi = async (req, res, next) => {
	try {
		let { authorization, authtoken } = req.headers;
		let besicAuthForHashing = authorization; //.split(" ");
		let basicAuth = Buffer.from(authorization.split(" ")[1], "base64").toString();
		let userName = basicAuth.split(":")[0];
		let password = basicAuth.split(":")[1];
		let redisKey = "NODE_OPEN_API_USERS";
		let isRedisData = await redisUtils.getRedisData(redisKey);
		if (isRedisData.responseCode != "200") {
			let responseVar = { responseCode: isRedisData.responseCode, responseMessage: isRedisData.responseMessage };
			let apiResponse = { serviceType: "OPEN_API_TOKEN_VALIDATION", apiResponseData: responseVar };
			return res.send(responseHandler.transform(apiResponse));
		}
		let isUserId = isRedisData.data[`${userName}`];
		if (!isUserId) {
			let responseVar = { responseCode: "401", responseMessage: "configuration not found for this user" };
			let apiResponse = { serviceType: "OPEN_API_TOKEN_VALIDATION", apiResponseData: responseVar };
			return res.send(responseHandler.transform(apiResponse));
		}
		let dataForHashing = `${besicAuthForHashing}#${req.headers.urn}`;
		let keyForHashing = isRedisData.data[`${userName}`].hashKey || "";
		let hashedData = commonUtis.createHMAC("sha512", keyForHashing, dataForHashing);
		if (hashedData.responseCode != "200") {
			let apiResponse = { serviceType: "OPEN_API_TOKEN_VALIDATION", apiResponseData: hashedData };
			return res.send(responseHandler.transform(apiResponse));
		}
		if (hashedData.responseData !== authtoken) {
			let responseVar = { responseCode: "401", responseMessage: "unauthorized access" };
			let apiResponse = { serviceType: "OPEN_API_TOKEN_VALIDATION", apiResponseData: responseVar };
			return res.send(responseHandler.transform(apiResponse));
		}
		if (isRedisData.data[`${userName}`].athPassword !== password) {
			let responseVar = { responseCode: "401", responseMessage: "Incorrect Password For Authorization" };
			let apiResponse = { serviceType: "OPEN_API_TOKEN_VALIDATION", apiResponseData: responseVar };
			return res.send(responseHandler.transform(apiResponse));
		}
		next();
	} catch (error) {
		let apiResposne = { code: "500", message: "something went wrong" + error, serviceType: "OPEN_API_HEADER_VALIDATION", apiResponseData: {} };
		return res.send(responseHandler.transform(apiResposne));
	}
};
