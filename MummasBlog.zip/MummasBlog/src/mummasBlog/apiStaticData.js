apiStaticData={
    responseCode: {
        Success: "200",
        Failure: "401",
        Error: "500" 
      },
      responseMessage: {
          Success: "Success",
          somethingWentWrong: "Something went wrong",
          Login_successful: "Login Successful",
          SessionCreation:"Session cant be created",
          InvalidChoice:"Invalid choice",
          TerminalVersionError:"Not received data from terminal version",
          redisValidationFailure:"Failure in redis validation",
          MERCHANTID_STATUS:"Invalid Merchant Info Key",
          REDIS_FAILURE:"Failure in Redis",
          MONGO_STATUS:"Can not dump data in mongodb",
          USER_ID_MISMATCH:"UserId mismatched",
          OTP_SENT:"Otp sent to the user",
          INVALID_OTP:"Invalid otp",
          SESSION_TIMEOUT:"Session Timeout"
  
  
      },  

      mongotableName:"signUp",
      redisKeys:{
        userInfo:"USER_INFO_{userId}",
        otpSession:"SESSION_{userId}",
      },
      redisExpire:300,
}
module.exports=apiStaticData;