const crypto = require("crypto");

require('mongodb')
const Mongocon=require("../../db/Connector")
const encrypt = async (key, iv) => {
  const str = randomNo(5);
  const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
  let crypt = cipher.update(str, "utf8", "base64");
  crypt += cipher.final("base64");
  return crypt;
};

const ran = (length) => {
  return Math.round(
    Math.pow(36, length + 1) - Math.random() * Math.pow(36, length)
  )
    .toString(36)
    .slice(1);
};

const time = () => {
  var date = new Date();
  let year = date.getFullYear().toString();
  let month = date.getMonth().toString();
  if (month.length === 1) {
    month = "0" + month;
  }
  let hour = date.getHours().toString();
  if (hour.length === 1) {
    hour = "0" + hour;
  }
  let min = date.getMinutes().toString();
  if (min.length === 1) {
    min = "0" + min;
  }
  let sec = date.getSeconds().toString();
  if (sec.length === 1) {
    sec = "0" + sec;
  }
  let mili = date.getMilliseconds().toString();

  if (mili.length === 1) {
    mili = "00" + mili;
  }
  if (mili.length === 2) {
    mili = "0" + mili;
  }
  return (
    year +
    ran(1) +
    month +
    ran(1) +
    hour +
    ran(1) +
    min +
    ran(1) +
    sec +
    ran(1) +
    mili 
  );
};

exports.createUserId = () => {
  let userId = time();
  if (userId.length > 20) {
    userId = userId.substring(0, 32);
  }
  return userId;
};

exports.generateOtp=()=>{
  let otp=(Math.floor((Math.random()*10000)+1)).toString();
  if(otp.length===1)
  otp="000"+otp;
  else if(otp.length===2)
  otp="00"+otp;
  else if(otp.length===3)
  otp="0"+otp;
  return otp;
  
}


exports.dumpDataInMongo = async (userSignUp) => {
  let apiResponse;
  try {
    let db = Mongocon.LoginDB();
    db.collection(apiStaticData.mongotableName).insertOne(userSignUp)
    return "Rgistered Successfully";
  } catch (error) {
      apiResponse = {
      code: apiStaticData.responseCode.Failure,
      message: apiStaticData.responseMessage.MONGO_STATUS + error,
      serviceType: apiStaticData.serviceType.login,
      apiResponseData: {},
    };
    return apiResponse;
  }
};

 