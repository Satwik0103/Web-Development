
const utils=require("./utils")
const commonutils = require("../commonUtils/utility");
const redisUtils = require("../commonUtils/redisUtils");
const apiStaticData = require("./apiStaticData");
const responseHandler = require("../commonUtils/responseHandler");
var nodemailer = require('nodemailer');
const qr = require('qrcode');

exports.userSignUp=async(req,res)=>{
    try{
        let userId= utils.createUserId();
        let userSignUp=req.body;
        userSignUp.userId=userId;
        //Save data in Redis
        let userInfo=apiStaticData.redisKeys.userInfo.replace("{userId}", userId);
        let redisData = await redisUtils.getRedisData(userInfo);
        if (redisData.responseCode != "200") {
        await redisUtils.setRedisData(userInfo,userSignUp)
        redisData = await redisUtils.getRedisData(userInfo);
        if (redisData.responseCode === "200") {


          console.log(redisData);
            const status=await utils.dumpDataInMongo(userSignUp)
            userSignUp.status=status;
            generateOtpEmail(req,res,userId);
            //res.send(userSignUp);
        }
        else{
            let apiResponseValue = {
                responseCode: apiStaticData.responseCode.Failure,
                responseMessage: apiStaticData.responseMessage.somethingWentWrong,
                responseData: {},
              };
              let apiResponse = {
               // serviceType: apiStaticData.serviceType.sessionKeyGeneration,
                apiResponseData: apiResponseValue,
              };
              return res.send(responseHandler.transform(apiResponse));

        }
        }

        else{
        //Save data in Mongo
        const status=await utils.dumpDataInMongo(userSignUp)
        userSignUp.status=status;
        res.send(userSignUp);
        }
    }
    catch (error) {
        apiResponseValue = {
         responseCode: apiStaticData.responseCode.Failure,
         responseMessage: apiStaticData.responseMessage.somethingWentWrong,
         responseData: {},
       };
         apiResponse = {
         //serviceType: apiStaticData.serviceType.login,
         apiResponseData: apiResponseValue,
       };
   
       return res.send(responseHandler.transform(apiResponse));
     }

  

//Save data in DB

}

//I need userId which i am sending in response after pressing signup button
const generateOtpEmail=async(req,res,userId)=>{

  const otp=utils.generateOtp();
 
 // let userId=req.body.userId;
  let otpSessionMail = apiStaticData.redisKeys.otpSession.replace("{userId}",userId );
  let otpDetail={
    "userId":req.body.userId,
    "email":req.body.email,
    "otp":otp
  }
  let otpDetails={
    "userId":req.body.userId,
    "email":req.body.email,
    "otp":otp
  }

let redisData = await redisUtils.setRedisData(otpSessionMail, otpDetail);
redisUtils.setExpireTimeForRedisData(
  otpSessionMail,
  apiStaticData.redisExpire
);
  
  if (redisData.responseCode === "200") {
   //SEND MAIL
  console.log(redisData);
//   var smtpConfig = {
//     host: 'smtp.gmail.com',
//     port: 465,
//     secure: true, // use SSL
//     auth: {
//         user: 'satwik0103@gmail.com',
//         pass: 'rmndonatyxghzfdv'
//     }
// };
var smtpConfig = {
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // use SSL
  auth: {
    user: 'satwik0103@gmail.com',
    pass: 'rmndonatyxghzfdv'
  },
  tls: {
    ciphers: "SSLv3",
  },
};
var transporter = nodemailer.createTransport(smtpConfig);
var mailOptions = {
  from: 'satwik0103@gmail.com',
  to: 'shagunmutreja16@gmail.com',
  subject: 'Your otp is',
  text: `Your otp is  ${otp}`
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
apiResponseValue = {
  responseCode: apiStaticData.responseCode.Success,
  responseMessage: apiStaticData.responseMessage.OTP_SENT,
  responseData: otpDetails,
};
  apiResponse = {
  //serviceType: apiStaticData.serviceType.login,
  apiResponseData: apiResponseValue,
};

return res.send(responseHandler.transform(apiResponse));
  
  
  }
  else{
    apiResponseValue = {
      responseCode: apiStaticData.responseCode.Failure,
      responseMessage: apiStaticData.responseMessage.USER_ID_MISMATCH,
      responseData: {},
    };
      apiResponse = {
      //serviceType: apiStaticData.serviceType.login,
      apiResponseData: apiResponseValue,
    };

    return res.send(responseHandler.transform(apiResponse));
  }

 
}
exports.verifyOtp=async(req,res)=>{
  const otp=req.body.otp;
  const userId=req.body.userid;
  let otpSessionMail = apiStaticData.redisKeys.otpSession.replace("{userId}",userId );
  let redisData = await redisUtils.getRedisData(otpSessionMail);
  if (redisData.responseCode != "200") {
    apiResponseValue = {
      responseCode: apiStaticData.responseCode.Failure,
      responseMessage: apiStaticData.responseMessage.SESSION_TIMEOUT,
      responseData: {},
    };
      apiResponse = {
      //serviceType: apiStaticData.serviceType.login,
      apiResponseData: apiResponseValue,
    };

    return res.send(responseHandler.transform(apiResponse));
  }
  else{
    let otpThroughRedis=redisData.data.otp;
    if(otpThroughRedis==otp){
    apiResponseValue = {
      responseCode: apiStaticData.responseCode.Success,
      responseMessage: apiStaticData.responseMessage.Success,
      responseData: {"status":"OTP Verified"},
    };
      apiResponse = {
      //serviceType: apiStaticData.serviceType.login,
      apiResponseData: apiResponseValue,
    };
    return res.send(responseHandler.transform(apiResponse));
  }
else{
  apiResponseValue = {
    responseCode: apiStaticData.responseCode.Failure,
    responseMessage: apiStaticData.responseMessage.INVALID_OTP,
    responseData: {},
  };
    apiResponse = {
    //serviceType: apiStaticData.serviceType.login,
    apiResponseData: apiResponseValue,
  };

  return res.send(responseHandler.transform(apiResponse));

}
    
  }
  }

exports.generateQRCode=async(req,res)=>{
let data = {
    id: 1,
    name: "Satwik",
    email: "satwik0103@gmail.com"
};
  
let strData = JSON.stringify(data)
let rep;
await qr.toFile('./user.png',strData) ;
let resp=await qr.toFileStream(strData);

qr.toString(strData, {type:'terminal'},
                    function (err, QRcode) {
   
    if(err) return console.log("error occurred")
   rep=QRcode;
    console.log(QRcode)
});
  
qr.toDataURL(strData, function (err, code) {
    if(err) return console.log("error occurred")
    console.log(code)
})
res.send(resp);

}

exports.userLogin=async(req,res)=>{
    const userId=req.body.userId;
    let userInfo=apiStaticData.redisKeys.userInfo.replace("{userId}", userId);
        let redisData = await redisUtils.getRedisData(userInfo);
        if (redisData.responseCode != "200") {
          let apiResponseValue = {
            responseCode: apiStaticData.responseCode.Failure,
            responseMessage: apiStaticData.responseMessage.USER_ID_MISMATCH,
            responseData: {},
          };
          let apiResponse = {
           // serviceType: apiStaticData.serviceType.sessionKeyGeneration,
            apiResponseData: apiResponseValue,
          };
          return res.send(responseHandler.transform(apiResponse));
        
        }
        else{
          await(authenticateUser(redisData,req));
        }



}

const authenticateUser=async(redisData,req)=>{
  if(redisData.data.username===req.body.username){
    if(redisData.data.password===req.body.password){
      let apiResponseValue = {
        responseCode: apiStaticData.responseCode.Success,
        responseMessage: apiStaticData.responseMessage.Success,
        responseData: {Userstatus:"LoggedIn"},
      };
      let apiResponse = {
       // serviceType: apiStaticData.serviceType.sessionKeyGeneration,
        apiResponseData: apiResponseValue,
      };
      return res.send(responseHandler.transform(apiResponse));
    
    }
    else{
      let apiResponseValue = {
        responseCode: apiStaticData.responseCode.Failure,
        responseMessage: apiStaticData.responseMessage.Failure,
        responseData: {Userstatus:"Invalid password"},
      };
      let apiResponse = {
       // serviceType: apiStaticData.serviceType.sessionKeyGeneration,
        apiResponseData: apiResponseValue,
      };
      return res.send(responseHandler.transform(apiResponse));
    }
  }
  else{
    let apiResponseValue = {
      responseCode: apiStaticData.responseCode.Failure,
      responseMessage: apiStaticData.responseMessage.Failure,
      responseData: {Userstatus:"Invalid Username"},
    };
    let apiResponse = {
     // serviceType: apiStaticData.serviceType.sessionKeyGeneration,
      apiResponseData: apiResponseValue,
    };
    return res.send(responseHandler.transform(apiResponse));
  }
}