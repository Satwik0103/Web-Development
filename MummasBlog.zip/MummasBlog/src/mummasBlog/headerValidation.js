const responseHandler = require("../commonUtils/responseHandler");
const apiStaticData = require("./apiStaticData");

exports.validateHeadersForLogin = (req, res, next) => {
  try {
    let {logintype } = req.headers;
    let err = 0;
    let errorMessage = "";
    if (logintype == null || logintype.trim().length === 0) {
      err = 1;
      errorMessage = "logintype should not be null and empty";
    }
    else {
      err = 0;
    }
    if (err) {
      let apiResponse = {
        //responseCode: apiStaticData.responseCode.Failure,
        responseMessage: errorMessage
      };
      return res.send(
        responseHandler.transform({
         // serviceType: apiStaticData.serviceType.headerValidationOfCliAuth,
          apiResponseData: apiResponse,
        })
      );
    }
    next();
  } catch (error) {
    let apiResponse = {
      //code: apiStaticData.responseCode.Error,
      message: apiStaticData.responseMessage.somethingWentWrong,
      //serviceType: apiStaticData.serviceType.headerValidationOfCliAuth,
      apiResponseData: {},
    };
    return res.send(responseHandler.transform(apiResponse));
  }

};
