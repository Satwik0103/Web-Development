const commonUtils = require("./utils");
const responseHandler = require("../commonUtils/responseHandler");
const apiStaticData = require("./apiStaticData");

exports.validatebodyDataForLogin = (req, res, next) => {
  try {
    let {
      username,
      password,
      email,
      gender,
      phoneNo
    } = req.body;
    let err = 0;
    let errorMessage = "";

    if (username == null || username.trim().length == 0) {
        err = 1;
        errorMessage = "username should not be null or empty";
      } 
    else if (password == null || password.trim().length == 0) {
      err = 1;
      errorMessage = "password should not be null or empty";
    }
    else if (email == null || email.trim().length == 0) {
        err = 1;
        errorMessage = "email should not be null or empty";
      } 
      else if (gender == null || gender.trim().length == 0) {
        err = 1;
        errorMessage = "gender should not be null or empty";
      } 
      else if (phoneNo == null || phoneNo.trim().length == 0) {
        err = 1;
        errorMessage = "phoneNo should not be null or empty";
      } 
     
    else {
      err = 0;
    }
    if (err) {
      let apiResponse = {
        responseCode: apiStaticData.responseCode.Failure,
        responseMessage: errorMessage
      };
      return res.send(
        responseHandler.transform({
          serviceType: apiStaticData.serviceType.reqbodyValidationOfCliAuth,
          apiResponseData: apiResponse,
        })
      );
    }
    next();
  } catch (error) {
    let apiResponse = {
      code: apiStaticData.responseCode.Error,
      message: apiStaticData.responseMessage.somethingWentWrong,
      serviceType: apiStaticData.serviceType.reqbodyValidationOfCliAuth,
      apiResponseData: {},
    };
    return res.send(responseHandler.transform(apiResponse));
  }
};


exports.validateEmailForOtp = (req, res, next) => {
  try {
    let {
      email,
      phoneNo
    } = req.body;
    let err = 0;
    let errorMessage = "";

   
     if (email == null || email.trim().length == 0) {
        err = 1;
        errorMessage = "email should not be null or empty";
      } 
      else if (phoneNo == null || phoneNo.trim().length == 0) {
        err = 1;
        errorMessage = "phoneNo should not be null or empty";
      } 
     
    else {
      err = 0;
    }
    if (err) {
      let apiResponse = {
        responseCode: apiStaticData.responseCode.Failure,
        responseMessage: errorMessage
      };
      return res.send(
        responseHandler.transform({
          serviceType: apiStaticData.serviceType.reqbodyValidationOfCliAuth,
          apiResponseData: apiResponse,
        })
      );
    }
    next();
  } catch (error) {
    let apiResponse = {
      code: apiStaticData.responseCode.Error,
      message: apiStaticData.responseMessage.somethingWentWrong,
      serviceType: apiStaticData.serviceType.reqbodyValidationOfCliAuth,
      apiResponseData: {},
    };
    return res.send(responseHandler.transform(apiResponse));
  }
};


