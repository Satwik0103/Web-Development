const express = require("express");
const router = express.Router();
const mummaBlog = require('./mummaBlog');
const headerValidation = require("./headerValidation");
const bodyValidation = require("./reqBodyValidation");
const openApiValidator=require("../commonUtils/openApiTokenValidator")

router.post("/userSignUp", [
 // headerValidation.validateHeadersForLogin,
  bodyValidation.validatebodyDataForLogin,
  //openApiValidator.validateHeaders,
  //openApiValidator.validateAuthForOpenApi,
  mummaBlog.userSignUp
]);
//  router.post("/generateOtp",[

//   // bodyValidation.validateEmailForOtp,
//    mummaBlog.generateOtpEmail

//  ]);
 router.post("/verifyOtp",[
  mummaBlog.verifyOtp

 ])
 router.post("/generateQRCode",[
  mummaBlog.generateQRCode
 ])
router.post("/Login",[
  mummaBlog.userLogin
])

module.exports = router;
