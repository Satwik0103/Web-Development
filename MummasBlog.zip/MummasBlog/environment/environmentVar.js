const envDev={
    PORT:4000,
    //Local redis credentials
	redisHost: "127.0.0.1",
    redisPort: 6379,
	redisMaxClient: 30,

}
module.exports=envDev;