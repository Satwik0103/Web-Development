const createError = require("http-errors");
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const config = require("./environment/environmentVar");
const mongoConnect=require("./db/Connector")
const indexRouter = require("./routes/index");
const cors = require("cors");
const bp = require("body-parser");
const app = express();

// -----------Middlewares-----------------------------------------------------
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
app.use(cors());
app.set("view engine", "ejs");
app.use(bp.urlencoded({ extended: false }));
app.use(bp.json());

//Middlewares ends -------------------------------------------------------------

// Index Routing starts

app.use("/", indexRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
	next(createError(404));
});

// Redis Pool connection  /
const clientConnectionObj = require("./src/commonUtils/redisConnection");
const con = clientConnectionObj.createConnection();
clientConnectionObj.setConnection(con);
redisClient = clientConnectionObj.getConnection();
// End Redis Pool connection /



//Mongo DB connection
const start = async () => {
	try {
	mongoConnect.connectToServer(function (err, client) { });
	  app.listen(config.PORT, 
		() => console.log(`MummasBLog Started and listening on port ${config.PORT}!`));

	} catch (error) {
		return res.send({
				apiResponseCode: "500",
				apiResponseMessage: err.message,
				apiResponseFrom: "NODE",
				apiResponseTime: new Date().toLocaleString(),
				apiResponseData: {}
			});
	}
  };
  
  start();



// error handler
app.use(function (err, req, res, next) {
	// set locals, only providing error in development
	res.locals.message = err.message;
	res.locals.error = req.app.get("env") === "development" ? err : {};

	// render the error page
	res.status(err.status || 500);
	return res.send({
		apiResponseCode: "500",
		apiResponseMessage: err.message,
		apiResponseFrom: "NODE",
		apiResponseTime: new Date().toLocaleString(),
		apiResponseData: {}
	});
});


module.exports = app;