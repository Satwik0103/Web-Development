const { MongoClient } = require("mongodb");

const url = `mongodb+srv://root:root@cluster0.v2fnw.mongodb.net/?retryWrites=true&w=majority`;
var database="foodBlog";
var loginDb;


module.exports = {
    connectToServer: (callback)=> {
      MongoClient.connect(url, function (err, client) {
        if (err) {
          console.log("------ CAN NOT CONNECT TO MONGO DB URL ---------"+err);
          process.exit(1);
        } else {
          loginDb = client.db(`${database}`);
          console.log("------CONNECT TO MONGO DB URL ---------");
          return callback(err);
        }
      });
    },
  
    LoginDB: ()=> {
      return loginDb;
    }
  }




